package com.example.msimple.persistance.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.lifecycle.LiveData
import androidx.room.OnConflictStrategy
import com.example.msimple.data.vos.ProgramVO

@Dao
interface ProgramDao {
    @Query("Select * from program_table where programId =:id")
    fun getProgramById(id : String) : LiveData<ProgramVO>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun saveProgramList(programList: MutableList<ProgramVO>) : List<Long>
}