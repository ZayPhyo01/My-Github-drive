package com.example.msimple.data.vos

import androidx.room.*
import com.example.msimple.persistance.typeconveter.SessionConveter
import com.google.gson.annotations.SerializedName

@Entity(tableName = "program_table")
data class ProgramVO(

        @PrimaryKey
        @ColumnInfo
        @SerializedName("program-id")
        val programId: String,

        @ColumnInfo
        @SerializedName("title")
        val title: String,

        @ColumnInfo
        @SerializedName("image")
        val image: String,

        /*   @ColumnInfo
           @SerializedName("average-lengths")
           val averageLengths: List<Int>,*/

        @ColumnInfo
        @SerializedName("description")
        val description: String,

        @ColumnInfo
        @TypeConverters(SessionConveter::class)
        @SerializedName("sessions")
        val sessionsList: List<SessionVO>
)
