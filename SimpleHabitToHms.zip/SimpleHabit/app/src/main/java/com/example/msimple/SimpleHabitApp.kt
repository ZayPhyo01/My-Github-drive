package com.example.msimple

import android.app.Application
import com.example.msimple.data.model.CategoryModel
import com.example.msimple.data.model.CurrentProgramModel
import com.example.msimple.data.model.TopicModel
import com.example.msimple.data.model.UserModelImpl

class SimpleHabitApp : Application(){

    override fun onCreate() {
        super.onCreate()
        CategoryModel.initModel(applicationContext)
        CurrentProgramModel.initModel(applicationContext)
        TopicModel.initModel(applicationContext)
        UserModelImpl.initModel(applicationContext)
    }
}
