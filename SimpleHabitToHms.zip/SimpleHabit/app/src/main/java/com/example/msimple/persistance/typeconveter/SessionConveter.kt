package com.example.msimple.persistance.typeconveter

import androidx.room.TypeConverter
import com.example.msimple.data.vos.ProgramVO
import com.example.msimple.data.vos.SessionVO
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class SessionConveter {

    @TypeConverter
    fun toString(obj: MutableList<SessionVO>): String {
        val gson = Gson()
        return gson.toJson(obj)
    }

    @TypeConverter
    fun fromString(string : String) : MutableList<SessionVO> {
        val gson = Gson()
        val type = object : TypeToken<MutableList<SessionVO>>() {

        }.type
        return gson.fromJson(string, type)
    }

}