package com.example.msimple.mvp.view

import com.example.msimple.data.vos.ProgramVO

interface DetailView : BaseView {
    fun showDetailProgram(programVO: ProgramVO)
}