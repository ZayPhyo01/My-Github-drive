package com.example.msimple.mvp.view

import com.example.msimple.data.vos.LoginUserVO

interface LoginView : BaseView {
    fun nevigateTo()
}