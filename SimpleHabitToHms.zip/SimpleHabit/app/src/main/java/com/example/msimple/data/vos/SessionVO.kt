package com.example.msimple.data.vos

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

@Entity
data class SessionVO(
        @ColumnInfo
        @PrimaryKey
        @SerializedName("session-id")
        val session_id: String,
        @ColumnInfo
        val title: String,
        @ColumnInfo
        @SerializedName("length-in-seconds")
        val length_in_seconds: Int,
        @ColumnInfo
        val file_path: String

        /* get() = (length_in_seconds / 60).toString() + " mins",*/
)
