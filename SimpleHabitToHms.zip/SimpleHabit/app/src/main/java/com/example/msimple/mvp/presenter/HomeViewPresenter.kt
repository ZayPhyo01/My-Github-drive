package com.example.msimple.mvp.presenter

import android.util.Log
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.Observer
import com.example.msimple.data.model.CategoryModel
import com.example.msimple.data.model.CurrentProgramModel
import com.example.msimple.data.model.TopicModel
import com.example.msimple.data.model.UserModelImpl
import com.example.msimple.data.vos.*
import com.example.msimple.mvp.view.HomeView
import java.util.*

class HomeViewPresenter : BasePresenter<HomeView>(), IHomeViewPresenter {
    override fun onTapCurrentItem() {
         mView.nevigateToCurrentDetail(id)
    }

    override fun onTapCategoryList(lifecycleOwner: LifecycleOwner,id : String) {
        Log.d("User tap "," ${id}")
        categorModel.getProgramVO(id).observe(lifecycleOwner, object : Observer<ProgramVO>{
            override fun onChanged(t: ProgramVO?) {
                 mView.nevigateToCategoryDetail(id)
            }
        })
    }




    val topicModel: TopicModel
    lateinit var id: String
    val categorModel: CategoryModel
    val currentModel: CurrentProgramModel
    val userModel : UserModelImpl

    init {
        topicModel = TopicModel
        categorModel = CategoryModel
        currentModel = CurrentProgramModel
        userModel = UserModelImpl
    }

    //Todo to fix current program
    override fun onUiReady(lifecycleOwner: LifecycleOwner) {

        userModel.getUserInfo().observe(lifecycleOwner,object : Observer<LoginUserVO>{
            override fun onChanged(t: LoginUserVO?) {
                if(t==null){
                    mView.nevigateToLogin()
                    return
                }
            }
        })

        categorModel.getCategory().observe(lifecycleOwner, object : Observer<MutableList<CategoryVO>> {
            override fun onChanged(t: MutableList<CategoryVO>?) {
                val debug = t
                Log.d("t in presenter ", " ${t!!.size}")
                mView.showCategoryList(t!!)
            }
        })


        currentModel.getCurrentProgram().observe(lifecycleOwner, object : Observer<CurrentVO> {
            override fun onChanged(t: CurrentVO?) {
                // val debug = t
//                id = t!!.programId
//               mView.showCurrentProgram(t!!)
            }

        })
        topicModel.getTopic().observe(lifecycleOwner, object : Observer<MutableList<TopicVO>> {
            override fun onChanged(t: MutableList<TopicVO>?) {
                mView.showTopicList(t!!)
            }
        })
    }


}