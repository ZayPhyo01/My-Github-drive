package com.example.msimple.utils

object AppConstants {

    const val BASE_URL = "http://padcmyanmar.com/"
    const val CATEGORIES_URL = "padc-5/simple-habits/getCategoriesPrograms.php"
    const val TOPIC_URL = "padc-5/simple-habits/getTopics.php"
    const val LOGIN_URL = "padc-3/mm-news/apis/v1/login.php"
    const val ACCESS_TOKEN = "b002c7e1a528b7cb460933fc2875e916"
    const val PROGRAM_ID = "ABC"
    const val CURRENT_PROGRAM_URL = "padc-5/simple-habits/getCurrentProgram.php"
}
