package com.example.msimple.persistance.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import android.icu.util.Currency
import androidx.lifecycle.LiveData
import androidx.room.OnConflictStrategy
import com.example.msimple.data.vos.CurrentVO

@Dao
interface CurrentProgramDao {
    @Query("Select * from current_table")
    fun getCurrentProgram() : LiveData<CurrentVO>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun saveCurrentProgram(currentVO: CurrentVO) : Long
}