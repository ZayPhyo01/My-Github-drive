package com.example.msimple.activitiy

import android.content.Context
import android.content.Intent
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AlertDialog
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import androidx.lifecycle.*
import androidx.lifecycle.ViewModelProviders


import com.example.msimple.delegate.OnClickItem
import com.example.msimple.R
import com.example.msimple.adapter.CategoryAdapter
import com.example.msimple.adapter.TopicsAdapter

import com.example.msimple.data.vos.CategoryVO
import com.example.msimple.data.vos.CurrentVO
import com.example.msimple.data.vos.ProgramVO
import com.example.msimple.data.vos.TopicVO
import com.example.msimple.mvp.presenter.HomeViewPresenter

import com.example.msimple.mvp.view.HomeView
import com.example.msimple.utils.AppConstants
import com.example.msimple.view.pod.LoginUserViewPod
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : BaseActivity(), OnClickItem, HomeView {
    override fun nevigateToLogin() {
         startActivity(LoginActivity.newIntent(this))
    }

    override fun nevigateToCurrentDetail(id : String) {
        var currentDetailIntent = DetailActivity.newIntent(this)
        currentDetailIntent.putExtra(AppConstants.PROGRAM_ID,id)
        startActivity(currentDetailIntent)
    }

    override fun nevigateToCategoryDetail(id : String) {
        var categoryDetailIntent = DetailActivity.newIntent(this)
        categoryDetailIntent.putExtra(AppConstants.PROGRAM_ID,id)
        startActivity(categoryDetailIntent)
    }


    override fun showCurrentProgram(currentVO: CurrentVO) {
        tvCurrenttitle.setText(currentVO.title)
    }

    override fun showTopicList(topicList: MutableList<TopicVO>) {
        topicsAdapter.setNewData(topicList)

    }

    override fun showCategoryList(catgoryList: MutableList<CategoryVO>) {
        Log.d("Category list size in activity", "${catgoryList.size}")
        categoryAdapter.setNewData(catgoryList)
    }


    // var viewPod: LoginUserViewPod


    lateinit var categoryAdapter: CategoryAdapter
    lateinit var topicsAdapter: TopicsAdapter
    lateinit var mPresenter: HomeViewPresenter

    //  var alertDialog: AlertDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mPresenter = ViewModelProviders.of(this).get(HomeViewPresenter::class.java)
        mPresenter.initView(this)
        categoryAdapter = CategoryAdapter(this)

        topicsAdapter = TopicsAdapter()
        mTopicList.adapter = topicsAdapter
        mTopicList.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(this)
        mCategoryList.adapter = categoryAdapter
        val layoutManager = androidx.recyclerview.widget.LinearLayoutManager(this)
        mCategoryList.layoutManager = layoutManager
        mTopicList.isNestedScrollingEnabled = false
        mCategoryList.isNestedScrollingEnabled = false
        mPresenter.onUiReady(this)
        tapCurrentProgram()



        //   viewPod = LoginUserViewPod(this)

        /*  alertDialog = AlertDialog.Builder(this)
                  .setTitle("User Profile")
                  .setView(LayoutInflater.from(this).inflate(R.layout.view_pod_login_user, null, false))
                  .create()*/
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            val id = menuItem.itemId
            when (id) {
                /*  R.id.action_home -> Log.d("Now you ", "at home")
                  R.id.action_profile ->

                    //  alertDialog.show()
                *//*  R.id.action_menu -> Log.d("","")*//*
                //show
                */
            }
            true
        }
    }


    override fun onTap(id : String) {
     mPresenter.onTapCategoryList(this,id)
    }


    companion object {


        fun newIntent(context: Context): Intent {
            return Intent(context, MainActivity::class.java)


        }
    }

    private fun tapCurrentProgram() {
        btnDay.setOnClickListener({
            mPresenter.onTapCurrentItem()
        })

    }
}
