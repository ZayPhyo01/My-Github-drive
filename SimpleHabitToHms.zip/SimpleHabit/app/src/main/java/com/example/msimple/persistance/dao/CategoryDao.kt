package com.example.msimple.persistance.dao

import android.util.Log
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.lifecycle.LiveData
import androidx.room.OnConflictStrategy
import com.example.msimple.data.model.CurrentProgramModel
import com.example.msimple.data.vos.CategoryVO
import com.example.msimple.data.vos.ProgramVO


@Dao
abstract class CategoryDao {
    @Query("Select * from category_table")
    abstract fun getAllCategory(): LiveData<MutableList<CategoryVO>>

    @Query("Select * from category_table")
    abstract fun getCategory() : MutableList<CategoryVO>


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract fun saveCategory(categoryList: MutableList<CategoryVO>): List<Long>


    fun insertCategory(categoryDao: CategoryDao, programDao: ProgramDao, categoryList: MutableList<CategoryVO>) {
Log.d("Work insert category"," done")

     val cat = categoryList
        Log.d("category size  in dao ", " ${categoryList.size}")
        var programList: MutableList<ProgramVO> = ArrayList<ProgramVO>()
        for (categroy in cat) {
            Log.d("category id "," ${categroy.categoryId}")
            for (program in categroy.programs) {

                programList.add(program)

                Log.d("Program id ", program.programId)
            }
        }

        val id = programDao.saveProgramList(programList)
        Log.d("program save id ", " $id")
        val id1 = categoryDao.saveCategory(categoryList)
        Log.d("category save id ", " $id1")
    }


}