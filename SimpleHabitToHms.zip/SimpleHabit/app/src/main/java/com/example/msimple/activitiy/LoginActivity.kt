package com.example.msimple.activitiy

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.lifecycle.ViewModelProviders

import com.example.msimple.delegate.LoginDelegate
import com.example.msimple.R
import com.example.msimple.data.model.UserModelImpl
import com.example.msimple.data.vos.LoginUserVO
import com.example.msimple.mvp.presenter.LoginPresenter
import com.example.msimple.mvp.view.LoginView
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : BaseActivity(), LoginView {

    override fun nevigateTo() {
 startActivity(MainActivity.newIntent(this))
    }


    lateinit var mPresenter: LoginPresenter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        mPresenter = ViewModelProviders.of(this).get(LoginPresenter::class.java)
        mPresenter.initView(this)


        val progressDialog = ProgressDialog(this)
        login.setOnClickListener {
            progressDialog.show()
            val emailOrPhone = email.text.toString()
            val pass = password.text.toString()
            mPresenter.onTapLogin(emailOrPhone,pass)

        }


    }
    companion object{
        fun newIntent(context: Context) : Intent{
            return Intent(context,LoginActivity::class.java)
        }
    }


}
