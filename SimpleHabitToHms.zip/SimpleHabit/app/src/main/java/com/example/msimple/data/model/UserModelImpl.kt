package com.example.msimple.data.model

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData

import com.example.msimple.delegate.LoginDelegate
import com.example.msimple.data.vos.LoginUserVO
import com.example.msimple.persistance.SimpleHabitDb


object UserModelImpl : BaseModel(), UserModel {
    override fun getUserInfo(): LiveData<LoginUserVO> {
       return mDatabase.loginDao.getLoginUser()
    }


    override fun login(emailOrPassword: String, password: String,success:()->Unit, fail:() -> Unit) {
        mRetrofit.login(emailOrPassword, password, object : LoginDelegate {
            override fun onSuccess(loginUser: LoginUserVO) {
                success.invoke()
                mDatabase.loginDao.insertLoginUser(loginUser)
            }

            override fun fail(message: String) {
                 fail.invoke()
            }
        })

    }
    /*  override val loginUser: LoginUserVO
          get() =


      override fun login(emailOrPassword: String, password: String, loginDelegate: LoginDelegate) {

          mRetrofit.login(emailOrPassword, password, object : LoginDelegate {
              override fun onSuccess(loginUser: LoginUserVO) {



              }

              override fun fail(message: String) {
                  loginDelegate.fail(message)
              }
          })
      }*/


}
