package com.example.msimple.mvp.view

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner

interface BaseView  {


}