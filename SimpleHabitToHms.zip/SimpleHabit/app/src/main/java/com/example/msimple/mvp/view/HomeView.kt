package com.example.msimple.mvp.view

import com.example.msimple.data.vos.CategoryVO
import com.example.msimple.data.vos.CurrentVO
import com.example.msimple.data.vos.TopicVO

interface HomeView : BaseView {
    fun showTopicList(topicList: MutableList<TopicVO>)
    fun showCategoryList(catgoryList: MutableList<CategoryVO>)
    fun showCurrentProgram(currentVO: CurrentVO)
    fun nevigateToCurrentDetail(id : String)
    fun nevigateToCategoryDetail(id : String)
    fun nevigateToLogin()
}