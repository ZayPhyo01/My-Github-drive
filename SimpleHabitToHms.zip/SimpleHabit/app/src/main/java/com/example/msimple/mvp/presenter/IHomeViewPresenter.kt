package com.example.msimple.mvp.presenter

import androidx.lifecycle.LifecycleOwner

interface IHomeViewPresenter  {
    fun onTapCurrentItem(  )
    fun onUiReady(lifecycleOwner: LifecycleOwner)
    fun onTapCategoryList(lifecycleOwner: LifecycleOwner,id : String)
}