package com.example.msimple.view.holders

import androidx.recyclerview.widget.RecyclerView
import android.view.View

import java.util.ArrayList

abstract class BaseHolder<T>(itemView: View) : androidx.recyclerview.widget.RecyclerView.ViewHolder(itemView), View.OnClickListener {

    init {
        itemView.setOnClickListener(this)
    }

    abstract fun bind(data: T)


    override fun onClick(v: View) {

    }
}
