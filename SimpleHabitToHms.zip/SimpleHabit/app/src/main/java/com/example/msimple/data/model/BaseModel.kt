package com.example.msimple.data.model

import android.content.Context
import com.example.msimple.network.RetrofitDA
import com.example.msimple.persistance.SimpleHabitDb

abstract class BaseModel {

    lateinit var mRetrofit: RetrofitDA
    lateinit var mDatabase : SimpleHabitDb

    fun initModel(context: Context)
    {
        mRetrofit = RetrofitDA.instance
        mDatabase = SimpleHabitDb.getInstance(context)
    }

}
