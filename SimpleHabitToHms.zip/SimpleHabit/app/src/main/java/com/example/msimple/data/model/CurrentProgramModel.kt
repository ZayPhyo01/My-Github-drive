package com.example.msimple.data.model

import android.util.Log
import androidx.lifecycle.LiveData
import com.example.msimple.delegate.CurrentProgramDelegate
import com.example.msimple.data.vos.CurrentVO
import com.example.msimple.data.vos.ProgramVO
import com.example.msimple.utils.AppConstants

object CurrentProgramModel : BaseModel(), ICurrentModel {

    override fun getProgramVO(id : String): LiveData<ProgramVO> {
         return mDatabase.programDao.getProgramById(id)
    }


    override fun getCurrentProgram(): LiveData<CurrentVO>{
        Log.d("GetCurrentProgram "," start work ")
        mRetrofit.loadCurrentProgram(AppConstants.ACCESS_TOKEN, 1, object : CurrentProgramDelegate {
            override fun onSuccess(currentVOS: CurrentVO) {

                val id = mDatabase.currentDao.saveCurrentProgram(currentVOS)
                Log.d("Current program id "," ${id}")
            }

            override fun fail(message: String) {

                Log.d("fail current in model", " !")
            }
        })
        return mDatabase.currentDao.getCurrentProgram()
    }


}
