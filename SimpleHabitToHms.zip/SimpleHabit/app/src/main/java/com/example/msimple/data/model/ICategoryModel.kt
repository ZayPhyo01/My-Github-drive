package com.example.msimple.data.model

import androidx.lifecycle.LiveData
import com.example.msimple.data.vos.CategoryVO
import com.example.msimple.data.vos.ProgramVO

interface ICategoryModel {
    fun getCategory():LiveData<MutableList<CategoryVO>>
    fun getProgramVO(id: String): LiveData<ProgramVO>


}
