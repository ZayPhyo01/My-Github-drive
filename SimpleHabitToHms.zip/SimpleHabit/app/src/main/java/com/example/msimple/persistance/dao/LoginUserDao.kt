package com.example.msimple.persistance.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

import com.example.msimple.data.vos.LoginUserVO

@Dao
interface LoginUserDao {
//Todo change return type to livedata
    @Query("SELECT * FROM login_user")
    fun getLoginUser() : LiveData<LoginUserVO>

    @Insert
    fun insertLoginUser(loginUserVO: LoginUserVO): Long

    @Delete
    fun delete(loginUserVO: LoginUserVO)
}
