package com.example.msimple.data.vos

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

@Entity(tableName = "topic_table")
data class TopicVO(
        @PrimaryKey(autoGenerate = true)
        var topicId : Int,

        @ColumnInfo
        @SerializedName("topic-name")
        val topicName: String,

        @ColumnInfo
        @SerializedName("topic-desc")
        val topicDesc: String,

        @ColumnInfo
        @SerializedName("icon")
        val icon: String,

        @ColumnInfo
        @SerializedName("background")
        val background: String
)
