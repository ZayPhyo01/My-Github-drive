package com.example.msimple.mvp.presenter

import androidx.lifecycle.ViewModel
import com.example.msimple.mvp.view.BaseView

open class BasePresenter <T : BaseView> : ViewModel(){
    lateinit var mView : T

    fun initView(view : T)
    {
        mView = view
    }
}