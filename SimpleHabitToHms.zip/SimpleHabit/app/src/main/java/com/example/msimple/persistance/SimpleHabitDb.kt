package com.example.msimple.persistance

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import android.content.Context
import com.example.msimple.data.vos.*
import com.example.msimple.persistance.dao.*
import com.example.msimple.persistance.typeconveter.CategoryConveter
import com.example.msimple.persistance.typeconveter.SessionConveter

@Database(entities = [LoginUserVO::class,CategoryVO::class,CurrentVO::class,ProgramVO::class,TopicVO::class], version = 17)
@TypeConverters(CategoryConveter::class,SessionConveter::class)
abstract class SimpleHabitDb : RoomDatabase() {
    abstract val loginDao: LoginUserDao
    abstract val categoryDao:CategoryDao
    abstract val currentDao : CurrentProgramDao
    abstract val programDao : ProgramDao
    abstract val topicDao : TopicDao

    companion object {

        private val DB_NAME = "sphabit.DB"
        var simpleHabitDb: SimpleHabitDb? = null

        fun getInstance(context: Context): SimpleHabitDb {

            if (simpleHabitDb == null) {
                simpleHabitDb = Room.databaseBuilder(context, SimpleHabitDb::class.java, DB_NAME)
                        .allowMainThreadQueries()
                        .fallbackToDestructiveMigration()
                        .build()
            }

            return simpleHabitDb!!
        }
    }


}

