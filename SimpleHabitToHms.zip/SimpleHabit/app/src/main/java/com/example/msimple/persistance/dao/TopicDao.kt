package com.example.msimple.persistance.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.lifecycle.LiveData
import com.example.msimple.data.vos.TopicVO

@Dao
interface TopicDao {
    @Query("Select * from topic_table")
    fun getAllTopic(): LiveData<MutableList<TopicVO>>

    @Insert
    fun saveTopic(topicVO: List<TopicVO>)
}