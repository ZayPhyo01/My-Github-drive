package com.example.msimple.mvp.presenter

import androidx.lifecycle.LifecycleOwner
import com.example.msimple.data.model.UserModelImpl
import com.example.msimple.mvp.view.LoginView

class LoginPresenter : BasePresenter<LoginView>(),ILoginPresenter {

    val userModel : UserModelImpl
    init {
        userModel = UserModelImpl
    }

    override fun onTapLogin(email: String, password: String) {
        userModel.login(email,password,{
            mView.nevigateTo()
        },{

        })
    }


}