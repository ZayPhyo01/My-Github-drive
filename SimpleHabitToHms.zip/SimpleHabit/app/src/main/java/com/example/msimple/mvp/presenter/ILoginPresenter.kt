package com.example.msimple.mvp.presenter

import androidx.lifecycle.LifecycleOwner

interface ILoginPresenter  {
    fun onTapLogin(email : String ,password : String)
}