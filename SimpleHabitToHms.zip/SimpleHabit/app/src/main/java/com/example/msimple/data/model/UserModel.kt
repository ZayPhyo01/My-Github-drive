package com.example.msimple.data.model

import androidx.lifecycle.LiveData
import com.example.msimple.delegate.LoginDelegate
import com.example.msimple.data.vos.LoginUserVO


interface UserModel {

    fun getUserInfo(): LiveData<LoginUserVO>

    fun login(emailOrPassword: String, password: String, success:()->Unit,fail:()-> Unit)

}
