package com.example.msimple.data.vos

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "login_user")
data class LoginUserVO (

    @PrimaryKey
    var userId: Int = 0,

    @ColumnInfo(name = "name")
    var name: String,

    @ColumnInfo(name = "email")
    var email: String,

    @ColumnInfo(name = "phone_no")
    var phoneNo: String,

    @ColumnInfo(name = "profile_url")
    var profileUrl: String,

    @ColumnInfo(name = "cover_url")
    var coverUrl: String
    )

