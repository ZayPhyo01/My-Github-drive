package com.example.msimple.activitiy

import androidx.appcompat.app.AppCompatActivity

abstract class BaseActivity : AppCompatActivity()
