package com.example.msimple.data.model

import androidx.lifecycle.LiveData
import com.example.msimple.delegate.TopicDelegate
import com.example.msimple.data.vos.TopicVO
import com.example.msimple.utils.AppConstants

object TopicModel   : BaseModel(), ITopicModel {

    override fun getTopic( ) :LiveData<MutableList<TopicVO>>{

        mRetrofit.loadTopic(AppConstants.ACCESS_TOKEN, 1, object : TopicDelegate {
            override fun onSuccess(topicVOS: List<TopicVO>) {
               mDatabase.topicDao.saveTopic(topicVOS)
            }

            override fun fail(message: String) {

            }
        })
        return mDatabase.topicDao.getAllTopic()

    }


}
