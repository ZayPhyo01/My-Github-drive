package com.example.msimple.data.vos

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.google.gson.annotations.SerializedName

@Entity(tableName = "current_table")
data class CurrentVO(

        @PrimaryKey
        @ColumnInfo
        @SerializedName("program-id")
        val programId: String,

        @ColumnInfo
        @SerializedName("title")
        val title: String,

        @ColumnInfo
        @SerializedName("current-period")
        val currentPeriod: String,

        @ColumnInfo
        @SerializedName("background")
        val background: String,

       /* @ColumnInfo
        @SerializedName("average-lengths")
        val averageLengths: List<Int>,*/

        @ColumnInfo
        @SerializedName("description")
        val description: String,

        @ColumnInfo
        @TypeConverters
        @SerializedName("sessions")
        val sessionsList: List<SessionVO>

)
