package com.example.msimple.view.holders

import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.util.Log
import android.view.View

import com.example.msimple.delegate.OnClickItem
import com.example.msimple.R
import com.example.msimple.adapter.ProgramAdapter
import com.example.msimple.data.vos.CategoryVO
import kotlinx.android.synthetic.main.item_view_category.view.*

class CategoryHolder(itemView: View, internal var onClickItem: OnClickItem) : BaseHolder<CategoryVO>(itemView) {

    internal var recyclerView: androidx.recyclerview.widget.RecyclerView
    internal var programAdapter: ProgramAdapter

    init {
        recyclerView = itemView.findViewById(R.id.rv_category_program)
        programAdapter = ProgramAdapter(onClickItem)
        recyclerView.adapter = programAdapter
        recyclerView.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(itemView.context, androidx.recyclerview.widget.LinearLayoutManager.HORIZONTAL, false)

    }


    override fun bind(data: CategoryVO) {
        Log.d("CategoryHolderTitle", data.title)
        itemView.tvCategoryTitle.setText(data.title)
        programAdapter.setNewData(data.programs!!)

    }


}
