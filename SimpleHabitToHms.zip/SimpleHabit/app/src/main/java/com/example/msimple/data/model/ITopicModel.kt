package com.example.msimple.data.model

import androidx.lifecycle.LiveData
import com.example.msimple.data.vos.CurrentVO
import com.example.msimple.data.vos.TopicVO

interface ITopicModel {

    fun getTopic() : LiveData<MutableList<TopicVO>>


}
