package com.example.msimple.delegate

interface BaseDelegate {
    fun fail(message: String)
}
