package com.example.msimple.mvp.presenter

import androidx.lifecycle.LifecycleOwner
import com.example.msimple.data.vos.ProgramVO
import com.example.msimple.mvp.view.DetailView

interface IDetailPresenter {
    fun onUiReady(id : String,lifecycleOwner: LifecycleOwner)
}