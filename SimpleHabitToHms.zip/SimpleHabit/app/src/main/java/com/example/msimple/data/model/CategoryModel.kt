package com.example.msimple.data.model

import android.util.Log
import androidx.lifecycle.LiveData
import com.example.msimple.delegate.CategoryDelegate
import com.example.msimple.data.vos.CategoryVO
import com.example.msimple.data.vos.ProgramVO
import com.example.msimple.utils.AppConstants

import java.util.HashMap

object CategoryModel : BaseModel(), ICategoryModel {


    override fun getCategory(): LiveData<MutableList<CategoryVO>> {
        Log.d("Work ", " get category")
        mRetrofit.loadCategory(AppConstants.ACCESS_TOKEN, "1", object : CategoryDelegate {
            override fun onSuccess(categoryVO: MutableList<CategoryVO>) {
            mDatabase.categoryDao.insertCategory(mDatabase.categoryDao, mDatabase.programDao, categoryVO)
            }

            override fun fail(message: String) {
                Log.d("Fail in model", message)
            }
        })

        val debug = mDatabase.categoryDao.getCategory()
        return  mDatabase.categoryDao.getAllCategory()

    }

    override fun getProgramVO(id: String): LiveData<ProgramVO> {
        return mDatabase.programDao.getProgramById(id)
    }


}
