package com.example.msimple.mvp.presenter

import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.Observer
import com.example.msimple.data.model.CategoryModel
import com.example.msimple.data.model.CurrentProgramModel
import com.example.msimple.data.vos.ProgramVO
import com.example.msimple.mvp.view.DetailView

class DetailPresenter : BasePresenter<DetailView>() , IDetailPresenter{
    val currentProgramModel : CurrentProgramModel
    val categoryModel : CategoryModel
    init {
        currentProgramModel = CurrentProgramModel
        categoryModel = CategoryModel
    }

    override fun onUiReady(id : String,lifecycleOwner: LifecycleOwner) {
        currentProgramModel.getProgramVO(id).observe(lifecycleOwner,object : Observer<ProgramVO>{
            override fun onChanged(t: ProgramVO?) {
               // mView.showDetailProgram(t!!)
            }
        })
        categoryModel.getProgramVO(id).observe(lifecycleOwner,object :Observer<ProgramVO>{
            override fun onChanged(t: ProgramVO?) {
                 mView.showDetailProgram(t!!)
            }
        })


    }

}