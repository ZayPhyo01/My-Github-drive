package com.example.msimple.data.vos

import androidx.room.*
import com.example.msimple.persistance.typeconveter.CategoryConveter
import com.google.gson.annotations.SerializedName
import java.util.Date

@Entity(tableName = "category_table")
data class CategoryVO(

        @PrimaryKey
        @ColumnInfo
        @SerializedName("category-id")
        val categoryId : String,

        @ColumnInfo
        val title: String,


      @TypeConverters( )
        @ColumnInfo
        val programs: MutableList<ProgramVO>

)
