package com.example.msimple.data.model

import androidx.lifecycle.LiveData
import com.example.msimple.data.vos.CategoryVO
import com.example.msimple.data.vos.CurrentVO
import com.example.msimple.data.vos.ProgramVO

interface ICurrentModel {

    fun getCurrentProgram( ) : LiveData<CurrentVO>
    fun getProgramVO(id : String) : LiveData<ProgramVO>

}
